<template>
  <div>
    <div class="verticalheight">
      <div class="about">
        <div class="content">
              <div class="logo-img">
                  <img src="http://img.zcool.cn/community/01ecf45705c2f232f875a944a26b1d.jpg">
              </div>
          　　蚁管家是历经实战检验的专业日用品企业管理ERP，能与【智能手机】顺畅链接、沟通、交互的移动办公软件。
          　　基于移动互联网新技术，它提供先进的企业管理功能，助力企业实现销售精细化管理、科学的经营决策、建立客户全方位资料储存库、多维度的财务报表，进行数据自动分析，更智能的预警提醒与自动化采购功能，开启企业管理智能时代。              
        </div>
        <div class="contact">
            <div class="tit">
                联系我们
            </div>
             <a class="phone" href="tel://15521293240">  
                <i class="icon iconfont icon-dianhua"></i>
                400-888-8888
            </a>
        </div>
      </div>
    <div>
  </div>
</template>

<script>
export default {
  name: 'about',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
@import "../assets/scss/about.scss";
</style>
