<template>
  <div id="app">
      <router-view></router-view>
  </div>
</template>

<script>

//图标库
import 'src/assets/ico/iconfont.css'

export default {
  name: 'app',
  components: {
  }
}
</script>

<style>

</style>
